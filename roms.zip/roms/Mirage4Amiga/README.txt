
                          MIRAGE LIBRARY 4 AMIGA

                          Converted by ADRDesign


This  library has been converted straight from the original Ensoniq Library
1:1,  no  resampling or bit depth changes applied.  Loops are preserved but
loopstart sometime's buggy, change it manually to fix the clipping.

Thanks to CommodoreJohn who sent me the images for this collection
Thanks also to Thomas from EAB for his tool chunked.  A lot of work saved!!
